<?php
    class Database{
        //DB PARAMS
        private $host = 'localhost';
        private $db_name = 'myblog';
        private $username = 'root';
        private $password = '123456';
        private $conn;

        //DB connection
        public function connect(){
            $this->conn = null;

            try{
                $this->conn = new PDO('mysql:host=' . $this->host. ';dbname='. $this->db_name, $this->username, $this->password);
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //=> erori daca interogariile pt baza de date sunt gresite
            } catch(PDOEXCeption $e){
                echo 'Connection Error: ' . $e->getMessage();
            }

            return $this->conn;
        }
    }